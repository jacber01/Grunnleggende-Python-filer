alder = int(input("Hvilket år er du født? ")) # Spør brukeren om fødselsår i terminal

referanseår = 2024 # Setter referanseår til 2024

beregning_alder = referanseår - alder # Regner ut alder

print("Du var", beregning_alder, "år gammel i 2024.") # Skriver ut alderen i terminal